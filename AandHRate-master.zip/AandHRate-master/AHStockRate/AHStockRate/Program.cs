﻿using System;
using System.IO;
using System.Linq;

namespace AHStockRate
{
    class Program
    {
        static void Main(string[] args)
        {
            var items = UnifyData.GetStockItems();

            var csvLines = items.Select(i => i.ToCSVLine());
            File.WriteAllLines($"{Constants.DataRoot}wellFormedData.csv", csvLines);
            Console.WriteLine("Hello World!");
            Console.ReadKey();
        }
    }
}
