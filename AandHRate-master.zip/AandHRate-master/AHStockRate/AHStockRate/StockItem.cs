﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AHStockRate
{
    public class StockItem
    {
        public string Name { get; set; }
        public string ChinaCode { get; set; }
        public string ChinaStock { get; set; }
        public string HKCode { get; set; }
        public DateTime ListDate { get; set; }

        public string ToCSVLine()
        {
            return $"{Name},{ChinaCode},{ChinaStock},{HKCode},{ListDate.ToShortDateString()}";
        }

        public static StockItem FromCSVLine(string csvLine)
        {
            if(string.IsNullOrEmpty(csvLine))
            {
                return null;
            }
            var es = csvLine.Split(',');
            if(es.Length != 5)
            {
                return null;
            }
            return new StockItem() { 
                Name = es[0],
                ChinaCode = es[1],
                ChinaStock = es[2],
                HKCode = es[3],
                ListDate = DateTime.Parse(es[4]),
            };

        }
    }
}
