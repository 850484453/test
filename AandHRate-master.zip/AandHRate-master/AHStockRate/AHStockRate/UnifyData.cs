﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace AHStockRate
{
    class UnifyData
    {
        
        public static List<StockItem> GetStockItems()
        {
            var allData = File.ReadAllLines($"{Constants.DataRoot}AHDataAll.csv");
            var datedData = File.ReadAllLines($"{Constants.DataRoot}AHDate.csv");
            var datedDataLookup = datedData.Skip(1).Select(s => { var ss = s.Split(','); return new KeyValuePair<string, string>(ss[2], ss[0]); });

            List<StockItem> items = new List<StockItem>();
            for(int i = 1; i < allData.Length; i++)
            {
                var d = allData[i].Split(',');
                var dateString = (datedDataLookup.Where(ddl => ddl.Key.Equals(d[3])).FirstOrDefault()).Value;
                if(string.IsNullOrEmpty(dateString))
                {
                    Console.WriteLine($"{allData[i]} could not find date.");
                    continue;
                }
                var item = new StockItem()
                {
                    Name = d[0],
                    ChinaCode = d[1].Split('.')[0],
                    ChinaStock = d[1].Split('.')[1],
                    HKCode = d[3],
                    ListDate = DateTime.Parse(dateString),
                };
                items.Add(item);
            }
            return items;
        }
    }
}
