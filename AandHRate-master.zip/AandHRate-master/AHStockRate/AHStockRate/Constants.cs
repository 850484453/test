﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AHStockRate
{
    static class Constants
    {
        public const string DataRoot = @"D:\github\AandHRate\data\";
    }
}
