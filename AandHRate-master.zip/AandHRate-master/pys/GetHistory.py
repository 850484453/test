from yahoo_historical import Fetcher
from joblib import Parallel, delayed
import multiprocessing


DataRoot = "D:\\github\\AandHRate\\data"

def GetOneStock(line):
    parts = line.split(",")
    fromDate = parts[4].split("/")
    chinaData = Fetcher(parts[1] + "." + parts[2], [int(fromDate[2]),int(fromDate[0]),int(fromDate[1])], [2019,11,13])
    with open(DataRoot + "\\his\\" + parts[0] + "CN.txt", 'w') as f:
        hisData = chinaData.getHistorical()
        for item in hisData.values:
            f.writelines(",".join(map(str, item))+ "\n")

    hkData = Fetcher(parts[3] + ".HK", [int(fromDate[2]),int(fromDate[0]),int(fromDate[1])], [2019,11,13])
    with open(DataRoot + "\\his\\" + parts[0] + "HK.txt", 'w') as f:
        hisData = hkData.getHistorical()
        for item in hisData.values:
            f.writelines(",".join(map(str, item)) + "\n")
    print("完成:" + parts[0])

with open(DataRoot + "\\wellFormedData.csv", encoding='utf-8') as allData:
    allLines = allData.read().splitlines()
    num_cores = multiprocessing.cpu_count()

    Parallel(n_jobs=num_cores)(delayed(GetOneStock)(i) for i in allLines)
    print("全部搞定")